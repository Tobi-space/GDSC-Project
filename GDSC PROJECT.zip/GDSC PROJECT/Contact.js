


// function sendEmail(){
//     Email.send({
// Host : "smtp.gmail.com",
// Username : "gamerzworld14@gmail.com",
// Password : "password",
// To : 'tobispace99@gmail.com',
// From : document.getElementById(email).value ,
// Subject : "This is the subject",
// Body : "Name:"  + document.getElementById(Name).value
// + "<br> Email:"  + document.getElementById(email).value
// + "<br> Subject:"  + document.getElementById(Subject).value
// }).then(
// message => alert("Message sent")
// );
// }


console.log("0||1="+(0||1));
console.log("1||2="+(1||2));
console.log("0 && 1 =" +(0 && 1));
console.log("1 && 2 =" +(1 && 2));






<script>
        function sendEmail(); reset(); return false;{
            Email.send({
    Host : "smtp.gmail.com",
    Username : "gamerzworld14@gmail.com",
    Password : "Habeeb15#",
    To : 'tobispace99@gmail.com',
    From : document.getElementById("email").value ,
    Subject : "This is the subject",
    Body : "Name:"  + document.getElementById("Name").value
    + "<br> Email:"  + document.getElementById("email").value
    + "<br> Subject:"  + document.getElementById("Subject").value
}).then(
  message => alert("Message sent")
);
        }
       </script>

onsubmit="sendEmail(); reset(); return false;"

